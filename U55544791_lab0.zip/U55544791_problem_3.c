#include <stdio.h>

void main() {
  unsigned int a;
  scanf("%x",&a);
  printf("%u",a);
}