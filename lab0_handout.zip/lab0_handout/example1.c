#include <stdio.h>

// accepts an integer a, and prints it out in decimal.
int main() {
    int a;
    
    scanf("%d", &a);
    printf("%d\n",a);
}
